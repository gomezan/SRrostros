
import sys

if __name__ == '__main__':

    test=r"C:\Users\Guatavita\PycharmProjects\pruebaModelos\ESPCN\test.py"
    prepare=r"C:\Users\Guatavita\PycharmProjects\pruebaModelos\ESPCN\prepare.py"
    train = r"C:\Users\Guatavita\PycharmProjects\pruebaModelos\ESPCN\train.py"

    archivoExec = test
    source_code = open(archivoExec).read()
    sys.argv = [archivoExec]
    exec(source_code)


